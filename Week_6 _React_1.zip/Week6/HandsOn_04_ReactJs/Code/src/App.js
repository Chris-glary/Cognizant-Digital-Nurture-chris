import logo from './logo.svg';
import './App.css';

// src/App.js

import { Posts } from './Posts';

function App() {
  return (
    <div className="App">
      <Posts />
    </div>
  );
}

export default App;

